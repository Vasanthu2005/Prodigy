const timerDisplay = document.querySelector('.timer-display');
const laps = document.getElementById('laps');

let minutes = 0, seconds = 0, milliseconds = 0;
let interval;
let isRunning = false;

//  Displaying time
function updateDisplay() {
  const min = minutes.toString().padStart(2, '0');
  const sec = seconds.toString().padStart(2, '0');
  const milli = milliseconds.toString().padStart(2, '0');
  timerDisplay.textContent = `${min}:${sec}:${milli}`;
}

// Start timer
function startStopwatch() {
  if (!isRunning) {
    isRunning = true;
    interval = setInterval(() => {
      milliseconds += 1;
      if (milliseconds === 100) {
        milliseconds = 0;
        seconds += 1;
      }
      if (seconds === 60) {
        seconds = 0;
        minutes += 1;
      }
      updateDisplay();
    }, 10);
  }
}

// Pause timer
function pauseStopwatch() {
  clearInterval(interval);
  isRunning = false;
}

// Reset timer
function resetStopwatch() {
  clearInterval(interval);
  isRunning = false;
  minutes = 0;
  seconds = 0;
  milliseconds = 0;
  updateDisplay();
  laps.innerHTML = '';
}

// Add laps
function addLap() {
  if (isRunning) {
    const min = minutes.toString().padStart(2, '0');
    const sec = seconds.toString().padStart(2, '0');
    const milli = milliseconds.toString().padStart(2, '0');

    const lapTime = `${min}:${sec}:${milli}`;
    const lapItem = document.createElement('li');
    lapItem.textContent = `Lap: ${lapTime}`;
    laps.appendChild(lapItem);
  }
}

// Event listeners
document.getElementById('start').addEventListener('click', startStopwatch);
document.getElementById('pause').addEventListener('click', pauseStopwatch);
document.getElementById('reset').addEventListener('click', resetStopwatch);
document.getElementById('lap').addEventListener('click', addLap);

// On page load calling
updateDisplay();