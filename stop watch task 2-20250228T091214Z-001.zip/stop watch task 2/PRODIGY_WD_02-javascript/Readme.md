# Stopwatch Web Application

A simple and interactive stopwatch web application that allows users to start, pause, reset the stopwatch, and record lap times. It features a responsive design and an intuitive interface, making it easy to track and measure time intervals.

## Deployment

The project is live and accessible at the following link:  
[Stopwatch Web App Live Demo](https://webappstopwatch.netlify.app/)

## Features
- **Start, Pause, and Reset**: Users can control the stopwatch with easy-to-use buttons.
- **Lap Time Recording**: Users can record lap times during the stopwatch run.
- **Responsive Design**: The app works on both desktop and mobile devices.
- **Interactive UI**: The stopwatch display updates in real-time, and lap times are listed in an accessible format.

## Technologies Used
- **HTML**: Structure and layout of the application.
- **CSS**: Styling the application, including the layout, buttons, and animations.
- **JavaScript**: Functionality of the stopwatch, including starting, pausing, resetting, and adding lap times.

## How It Works
1. **Start**: Click the "Start" button to begin the stopwatch. The timer will update every 10 milliseconds.
2. **Pause**: Click the "Pause" button to pause the stopwatch at any time.
3. **Reset**: Click the "Reset" button to reset the stopwatch to 00:00:00 and clear lap times.
4. **Lap**: Click the "Lap" button to record the current time as a lap and view it below the stopwatch display.

## Installation

To run this project locally:

1. **Clone the Repository**  
   Clone the project repository to your local machine:
   ```bash
   git clone https://github.com/shivlalsharma/PRODIGY_WD_02.git
   ```

2. **Navigate to the Project Directory**  
   Change to the project directory:
   ```bash
   cd PRODIGY_WD_02
   ```

3. **Open in Browser**  
   Open the `index.html` file in your web browser:
   ```bash
   open index.html
   ```
   Alternatively, you can right-click the file and select "Open With" > "Browser."

4. **Customize (Optional)**  
   Modify the HTML, CSS, or JavaScript files to customize the menu style or behavior according to your preferences.

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## Author

Created and deployed by **Shivlal Sharma**.  
- **GitHub**: [GitHub](https://github.com/shivlalsharma)
- **LinkedIn**: [LinkedIn](https://www.linkedin.com/in/shivlal-sharma-56ba5a284/)